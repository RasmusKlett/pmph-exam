#ifndef CONSTANTS
#define CONSTANTS

#if (WITH_FLOATS==0)
    typedef double REAL;
#else
    typedef float  REAL;
#endif

#endif // CONSTANTS
